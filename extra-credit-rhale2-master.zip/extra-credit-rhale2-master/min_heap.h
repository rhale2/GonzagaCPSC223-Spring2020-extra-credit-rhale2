
//----------------------------------------------------------------------
// Author: Rebekah Hale
// Course: CPSC 223, Spring 2020
// Assign: Extra Credit
// File:   min_heap.h
// Desc:   functions for a min heap
//----------------------------------------------------------------------


// PUT YOUR CLASS DEFINITION AND IMPLEMENTATION HERE

// Note: You will also need to create code in a separate file to test
// your implementation (preferrable using gtest as in previous assignments).

#ifndef MINHEAP_COLLECTION_H
#define MINHEAP_COLLECTION_H

#include <vector>
#include <algorithm>
#include <iostream>
#include <cmath>
#define COUNT 10

template <typename K, typename V>
class MinHeapCollection {
  public:	
    // create an empty linked list
    MinHeapCollection();													
    // copy a linked list
    MinHeapCollection(const MinHeapCollection<K,V>& rhs);						
    
    // assign a linked list
    MinHeapCollection<K,V>& operator=(const MinHeapCollection<K,V>& rhs);		
    
    // delete a linked list
    ~MinHeapCollection();													
    // insert a key-value pair into the collection
    void add(const K& key, const V& val);							
    
    // remove the minimum key-value pair from the collection
    void remove();													
	
    // returns the smallest key-value pair
    bool find(K& key, V& val) const;										
    // return all of the keys in ascending (sorted) order
    void heap_sort(std::vector<K>& keys) const;
	   
    // gets the size of the heap
    int size() const;													
    // prints the values in the heap
    void print() const;														
    // gets the height of the heap
    int height() const;
	
  private:	
    // heap node structure
    struct Node {
      K key;
      V value;
      Node* parent;
      Node* left;
      Node* right;
    };
	
    Node* root;
	
    // number of k-v pairs in the collection
    int collection_size;
	
    // helper to recursively empty search tree
    void make_empty(Node* subtree_root);								
	
    // helper to recursively build sorted list of keys
    void preorder(const Node* subtree, std::vector<K>& ks, std::vector<V>& vs) const;		
	
    // remove helper function
    bool remove_min(K& key, Node* subtree_root);
};


template <typename K, typename V>
// create an empty heap
MinHeapCollection<K,V> :: MinHeapCollection() :
collection_size(0), root(nullptr) { 

}

template <typename K, typename V>
// empty the heap
void MinHeapCollection<K,V> :: make_empty(Node* subtree_root) {
  bool truth = false;
  while (!truth) {
    truth = remove(subtree_root->key, subtree_root->value;
  }
}

template <typename K, typename V>
// delete a heap
MinHeapCollection<K,V> :: ~MinHeapCollection() {
  make_empty(root);
}

template <typename K, typename V>
// copy the heap
MinHeapCollection<K,V> :: MinHeapCollection(const MinHeapCollection<K,V>& rhs) :
collection_size(0), root(nullptr) {
  *this = rhs;
}

template <typename K, typename V>
// assign a heap to a new heap
MinHeapCollection<K,V>& MinHeapCollection<K,V> :: operator=(const MinHeapCollection<K,V>& rhs) {
  if (this == &rhs) {
    return *this;
  }
  make_empty(root);
  std::vector<K> keys;
  std::vector<V> values;
  preorder(rhs.root, keys, values);	

  for (int i = 0; i < keys.size(); ++i) {
    add(keys[i], values[i]);
  }	
  return *this;
}

template <typename K, typename V>
// helper to recursivly build the heap
void MinHeapCollection<K,V> :: preorder(const Node* subtree_root, std::vector<K>& keys, std::vector<V>& values) const {
  if (subtree_root == nullptr) {
    return;
  }

  keys.push_back(subtree_root->key);		
  values.push_back(subtree_root->value);
  preorder(subtree_root->left, keys, values);	
  preorder(subtree_root->right, keys, values);
}
	
template <typename K, typename V>
// finds the key_value pair in the heap
bool MinHeapCollection<K,V> :: find(K& keys, V& values) const {
  if (!root) {
    return false;
  }
    
  keys = root->key;
  values = root->value;
  return true;
}

template <typename K, typename V>
// removes a key-value pair from the heap
typename MinHeapCollection<K,V>::Node*
MinHeapCollection<K,V> :: remove(K& keys, Node* subtree_root) {
  if (!subtree_root) {
    return subtree_root;
  } 
  else if (!subtree_root->left && !subtree_root->right) {
    delete subtree_root;
    subtree_root = nullptr;
    return true;
  } 
  else {
    int h = height();
    int* direction = new int[h];
    int size = collection_size;

    for (int i = h - 1; i >= 0; i--) {
      direction[i] = size % 2;
      size = std::floor(size/2);
    }
    Node* ptr = root;
		
    for (int i = 1; i < h - 1; i++) {
      if (direction[i] == 0) {
        ptr = ptr->left;
      } 
      else if (direction[i] == 1) {
        ptr = ptr->right;
      }
    }

    if (ptr->left && !ptr->right) {
      subtree_root->key = ptr->left->key;
      subtree_root->value = ptr->left->value;
      delete ptr->left;
      ptr->left = nullptr;
    } 
    else if (ptr->left && ptr->right) {
      subtree_root->key = ptr->right->key;
      subtree_root->value = ptr->right->value;
      delete ptr->right;
      ptr->right = nullptr;
    }
    Node* perc_ptr = subtree_root;
    Node* min_child;
    K tmp_key;
    V tmp_val;
    bool is_valid_heap = false;
		
    if (collection_size == 3) {
      if (subtree_root->left && !subtree_root->right && subtree_root->key > subtree_root->left->key) {
        std::swap(subtree_root->key, subtree_root->left->key);
        std::swap(subtree_root->value, subtree_root->left->value);
	return subtree_root;
      }
    }
    while (!is_valid_heap) {
      if (perc_ptr->left && perc_ptr->right) {
        if (perc_ptr->left->key < perc_ptr->right->key) {
          min_child = perc_ptr->left;
        } 
        else {
          min_child = perc_ptr->right;
        }
      } 
      else {
        break;
      }

      if (perc_ptr->key > min_child->key) {
        tmp_key = perc_ptr->key;
	tmp_val = perc_ptr->value;
	perc_ptr->key = min_child->key;
	perc_ptr->value = min_child->value;
	min_child->key = tmp_key;
	min_child->value = tmp_val;
	perc_ptr = min_child;
      } 
      else {
	is_valid_heap = true;
      }
    }
  }	
  return subtree_root;
}

template <typename K, typename V>
// inserts a vlaue to the heap
void MinHeapCollection<K,V> :: add(const K& keys, const V& values) {
  Node* tmp = new Node;	
  tmp->key = keys;
  tmp->value = values;
  tmp->left = nullptr;
  tmp->right = nullptr;
  tmp->parent = nullptr;
  collection_size = collection_size + 1;
	
  if (!root) {
    root = tmp;
    return;
  } 
  else {
    int h = height();
    int* direction = new int[h];
    int size = collection_size;

    for (int i = h - 1; i >= 0; i--) {
      direction[i] = size % 2;
      size = std::floor(size/2);
    }
    Node* ptr = root;

    for (int i = 1; i < h - 1; i++) {
      if (direction[i] == 0) {
        ptr = ptr->left;
      } 
      else if (direction[i] == 1) {
	ptr = ptr->right;
      }
    }
		
    if (!ptr->left) {
      ptr->left = tmp;
      tmp->parent = ptr;
    } 
    else if (ptr->left && !ptr->right) {
      ptr->right = tmp;
      tmp->parent = ptr;
    }		
    K tmp_key;
    V tmp_val;
		
    while (tmp->parent && tmp->parent->key > tmp->key) {
      tmp_key = tmp->parent->key;
      tmp_val = tmp->parent->value;
      tmp->parent->key = tmp->key;
      tmp->parent->value = tmp->value;
      tmp->key = tmp_key;
      tmp->value = tmp_val;
      tmp = tmp->parent;
    }
  }		
}

template <typename K, typename V>
// gets the size of the heap
int MinHeapCollection<K,V> :: size() const {
  return collection_size;
}

template <typename K, typename V>
// prints out the heap
void MinHeapCollection<K,V> :: print() const {
  std::vector<K> keys;
  preorder(root, keys);
	
  for (int i = 0; i < size(); ++i) {
    std::cout << keys[i] << " ";
  }
  std::cout << std::endl;
}

template <typename K, typename V>
// gets the height
int MinHeapCollection<K,V> :: height() const {
  return std::ceil(std::log2(collection_size + 1));
}

template <typename K, typename V>
// remove a key-value from the heap
bool MinHeapCollection<K,V> :: remove_min(K& the_key, V& the_val) {
  bool found = find_min(the_key, the_val);
  root = remove(the_key, root);
  collection_size = collection_size - 1;
  return found;
}

template <typename K, typename V>
// sorts the key-value pairs in the heap
void MinHeapCollection<K,V> :: heap_sort(std::vector<K>& keys) const {
  MinHeapCollection<K,V> copy(*this);
  K tmp_key;
  V tmp_val;
	
  while (copy.size() > 0) {
    copy.find_min(tmp_key, tmp_val);
    keys.push_back(tmp_key);
    copy.remove_min(tmp_key, tmp_val);
  }
}
	
#endif
